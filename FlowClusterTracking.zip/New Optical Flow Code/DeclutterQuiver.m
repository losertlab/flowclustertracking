function [vx, vy, rel] = DeclutterQuiver(vx, vy, rel, s)
vx(mod(1:size(vx, 1), s) ~= 0, :, :) = 0;
vx(:, mod(1:size(vx, 2), s) ~= 0, :) = 0;
vy(mod(1:size(vy, 1), s) ~= 0, :, :) = 0;
vy(:, mod(1:size(vy, 2), s) ~= 0, :) = 0;
rel(mod(1:size(rel, 1), s) ~= 0, :, :) = 0;
rel(:, mod(1:size(rel, 2), s) ~= 0, :) = 0;