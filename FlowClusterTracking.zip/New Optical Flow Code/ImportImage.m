function ImportImage(importFolder, exportFolder, fileName)
info = imfinfo([importFolder, fileName]);
% info = info(1).ImageDescription; 
automateFlag = 1;
if automateFlag == 1
    %% Automated
%     ChLoc = strfind(info, 'channels');
%     FrLoc = strfind(info, 'frames');
    numChannels = 1;%str2double(info(ChLoc + 9));
    numFrames = length(info);%str2double(info(FrLoc + (7:9)));
elseif automateFlag == 0
    %% Manual
    disp(' ');
    disp(info);
    disp(' ');
    numChannels = input('Number of Channels? ');
    disp(' ');
    numFrames = input('Number of Frames? ');
    disp(' ');
%     startFrame = input('What is the First Frame? ');
%     disp(' ');
%     endFrame = input('What is the Last Frame? ');
%     disp(' ');
end
if numChannels == 1
    image = imread([importFolder, fileName], 1);
    image = zeros([size(image), numFrames, numChannels]);
    for i = 1:numFrames
        image(:, :, i) = imread([importFolder, fileName], i);
    end
    actinChannel = 1;
elseif numChannels == 2
    image = imread([importFolder, fileName], 1);
    image = zeros([size(image), numFrames, numChannels]);
    for i = 1:numFrames
        if mod(i, 10) == 0
            fprintf(['Frame ', num2str(i), ' of ', num2str(numFrames), '\n']);
        end
        for j = 1:numChannels
            image(:, :, i, j) = imread([importFolder, fileName], 2*(i - 1) + j);
        end
    end
    figure;
    subplot(1, 2, 1);
    imagesc(max(image(:, :, :, 1), [], 3));
    title('Channel 1');
    axis equal; axis off;
    subplot(1, 2, 2);
    imagesc(max(image(:, :, :, 2), [], 3));
    title('Channel 2');
    axis equal; axis off;
    disp(' ');
    actinChannel = input('Which is the actin channel? ');
    disp(' ');
    close all;
    if (actinChannel ~= 1) && (actinChannel ~= 2)
        error('Unexpected channel!');
    end
else
    error('Unexpected numChannels!');
end
OriginalImage.Image = uint16(image);
OriginalImage.NumChannels = numChannels;
OriginalImage.NumFrames = numFrames;
OriginalImage.ActinChannel = actinChannel;
try
    save([exportFolder, 'OriginalImage.mat'], 'OriginalImage');
catch
    save([exportFolder, 'OriginalImage.mat'], 'OriginalImage', '-v7.3');
end