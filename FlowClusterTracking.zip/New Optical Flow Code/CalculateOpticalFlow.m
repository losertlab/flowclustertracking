function CalculateOpticalFlow(exportFolder, wSig, image)

% Calculate Optical Flow
[vxMat, vyMat, relMat] = LKxOptFlowT(image, wSig);

% Make file
OpticalFlow.vxMat = vxMat;
OpticalFlow.vyMat = vyMat;
OpticalFlow.relMat = relMat;

% Save
save([exportFolder, 'OpticalFlow.mat'], 'wSig', 'vxMat', 'vyMat', 'relMat', '-v7.3');