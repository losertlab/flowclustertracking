%% Main Flow Tracking Analysis Script
%  The goal of this analysis is to track actin dynamics in actin
%  fluorescence movies using Optical Flow and Crocker-Grier Least-Squares
%  Minimization Particle Tracking.
function ControlScriptBatch(run, M1_spatial_multiplier, M1_time_multiplier, M1_peakThresh_multiplier, timeBtwFrames, fileName, importFolder, exportFolder, pxPerMicron, timeUnit, thetaInDegrees, dataGroup, dataGroupName)
%% Define Global Parameters


% % % % % --------- File Parameters --------- % % % % %

% File Location Parameters
% fileName
% importFolder
% exportFolder

% File Detail Parameters
% pxPerMicron      <---- Number of pixels per micron
% timeBtwFrames    <---- Time between two frames
% timeUnit         <---- Time in seconds = 1, Time in minutes = 2;
% thetaInDegrees   <---- The angle of rotation (used to align ridges)
% dataGroup        <---- Index for grouping data
% dataGroupName    <---- Name of the data for each index


% % % % % --------- Adjustable Analysis Parameters --------- % % % % %

% 1) Changes the amount of smoothing done on the bgSubImage
% The first two entries are spatial smoothing, third entry is time smoothing
smoothSig = [4, 4, 1]*M1_spatial_multiplier;

% 2) Changes the window size over which the optical flow vectors are calculated
% Small values - capture small waves/Large values - large waves
wSig = 3*M1_spatial_multiplier;

% 3,4) Changes the radii over which clusters are searched for
% Do not make minR smaller than the size of noise (2-3px minimum is suggested)
% maxR should be larger than the largest cluster you're searching for
minR = floor(4*M1_spatial_multiplier);
maxR = ceil(5*M1_spatial_multiplier);

% 5,6,7,8) Parameters used for Crocker-Grier Particle Tracking...
%
% peakThresh: the threshold of the cluster image which is used to identify
%       where peaks that should be tracked
% clusterRad: the radius used to group together "similarly pointed"
%       Optical Flow vectors
% peakSize: the input to "pkfnd.m" used to define the diameter of a tracked
%       particle and should be chosen carefully
% trackMaxDisp: the input to "track.m" used to determine the maximum
%       displacement that a particle can travel while still being tracked
peakThresh = 0.05;
clusterRad = ceil(3*M1_spatial_multiplier);
peakSize = ceil(10*M1_spatial_multiplier);
trackMaxDisp = ceil(7*M1_spatial_multiplier);

% 9, 10) Parameters for postprocessing of tracks
% 
% Minimum Track Length: used to eliminate tracks that are not long
%       enough to be considered "real tracks"
% Number of nearest neighbors in track smoothing: how many one-way nearest
%       neighbors should be averaged together during track smoothing
minTrackLength = 3;
trackSmoothNumNNs = 1;

% % Visual Flow Distribution Parameters
% distOption = 1;   %  <------- distOption = 1 means [0, 90], distOption = 2 means [0, 360]
% dataBinWidth = 5; % <------- plots will always be 2x this binWidth



% % -- All other parameters are contained in their respective functions -- % %

% Process Parameters
if timeUnit == 1
    secBtwFrames = timeBtwFrames;
elseif timeUnit == 2
    secBtwFrames = 60*timeBtwFrames;
else
    error('timeUnit not recognized');
end
thetaInRadians = thetaInDegrees*pi/180;

%% Set Global Parameters

% Set File Parameters
fileParams.fileName = fileName;
fileParams.dataGroup = dataGroup;
fileParams.dataGroupName = dataGroupName;
fileParams.importFolder = importFolder;
fileParams.exportFolder = exportFolder;
fileParams.pxPerMicron = pxPerMicron;
fileParams.secBtwFrames = secBtwFrames;
fileParams.thetaInDegrees = thetaInDegrees;
fileParams.thetaInRadians = thetaInRadians;

% Set Adjustable Analysis Parameters
mainAnalysisParams.smoothSig = smoothSig;
mainAnalysisParams.wSig = wSig;
mainAnalysisParams.minR = minR;
mainAnalysisParams.maxR = maxR;
mainAnalysisParams.peakThresh = peakThresh;
mainAnalysisParams.clusterRad = clusterRad;
mainAnalysisParams.peakSize = peakSize;
mainAnalysisParams.trackMaxDisp = trackMaxDisp;
mainAnalysisParams.minTrackLength = minTrackLength;
mainAnalysisParams.trackSmoothNumNNs = trackSmoothNumNNs;


% % Set Visual Flow Figure Parameters
% flowFigureImageParams.frameNum = frameNum;
% flowFigureImageParams.intGamma = intGamma;
% flowFigureImageParams.intThresh = intThresh;
% flowFigureImageParams.relGamma = relGamma;
% flowFigureImageParams.relThreshFac = relThreshFac;
% flowFigureImageParams.magGamma = magGamma;
% flowFigureImageParams.magThresh = magThresh;
% flowFigureImageParams.flowSig = flowSig;
% flowFigureImageParams.spacingA = spacingA;
% flowFigureImageParams.spacingFacA = spacingFacA;
% flowFigureImageParams.vecLineWidthA = vecLineWidthA;
% flowFigureImageParams.spacingB = spacingB;
% flowFigureImageParams.spacingFacB = spacingFacB;
% flowFigureImageParams.vecLineWidthB = vecLineWidthB;
% flowFigureImageParams.spacingC = spacingC;
% flowFigureImageParams.spacingFacC = spacingFacC;
% flowFigureImageParams.vecLineWidthC = vecLineWidthC;
% flowFigureImageParams.periodicxcmap1 = periodicxcmap1;
% flowFigureImageParams.periodicxcmap2 = periodicxcmap2;
% flowFigureImageParams.outlineLineWidth = outlineLineWidth;

% % Set Flow Distribution Parameters
% flowDistParams.distOption = distOption;
% flowDistParams.dataBinWidth = dataBinWidth;
% flowDistParams.showBinWidth = dataBinWidth*2;

%% Run Analysis Script
%  The goal of this part of the code is to generate the core files needed
%  for the analysis of actin dynamics using Optical Flow and Crocker-Grier
%  tracking

% Run MainAnalysisScript
if run(1) == 1
    MainAnalysisScript(fileParams, mainAnalysisParams);
end

%% Make Flow Figure Data
%  The goal of this part of the code is to generate the data to nicely show
%  the output of the Optical Flow part of the code

if run(2) == 1
    FlowFigureData(fileParams);
end

%% Make Flow Figure Images
% %  The goal of this part of the code is to generate the images that nicely
% %  show the output of the Optical Flow part of the code
% 
% if run(3) == 1
%     FlowFigureImages(fileParams, flowFigureImageParams);
% end

%% Make Flow Distribution Data
%  The goal of this part of the code is to generate the distributions of
%  the optical flow directions

if run(4) == 1
    FlowDistributionData(fileParams);
end

%% Make Flow Cluster Tracks Data
% The goal of this part of the code is to generate results from the
% tracking portion of MainAnalysisScript

if run(5) == 1
    FlowClusterTracksData(fileParams, mainAnalysisParams);
end

%% Make Flow Cluster Tracks Movies
% The goal of this part of the code is to generate movies of the tracks
% calculated in MainAnalysisScript

if run(6) == 1
    FlowClusterTracksMovies(fileParams);
end



