function SmoothImages(exportFolder, smoothSig, image)
% Smooth Image
[xFil, yFil, zFil] = DecomposedGaussian3(smoothSig, ceil(6*smoothSig + 1));
smoothImage = imfilter(imfilter(imfilter(double(image), xFil, 'replicate'), yFil, 'replicate'), zFil, 'replicate');

% Save
save([exportFolder, 'SmoothedImages.mat'], 'smoothImage', 'smoothSig'); 