%% Main Flow Tracking Analysis Script
%  The goal of this analysis is to track actin dynamics in actin
%  fluorescence movies using Optical Flow and Crocker-Grier Least-Squares
%  Minimization Particle Tracking.
function MainAnalysisScript(fileParameters, mainAnalysisParams)
%% Start MainAnalysisScript
fprintf('\n- - - Starting MainAnalysisScript - - -\n\n')

%% File Parameters

% Load Parameters
fileName = fileParameters.fileName;
importFolder = fileParameters.importFolder;
exportFolder = fileParameters.exportFolder;
pxPerMicron = fileParameters.pxPerMicron;
secBtwFrames = fileParameters.secBtwFrames;

% Create Export Folder
if ~exist(exportFolder, 'dir')
    mkdir(exportFolder);
end

% Save Parameters
save([exportFolder, 'FileParameters.mat'], 'fileParameters');

%% Main Analysis Parameters
smoothSig = mainAnalysisParams.smoothSig;
wSig = mainAnalysisParams.wSig;
minR = mainAnalysisParams.minR;
maxR = mainAnalysisParams.maxR;
clusterRad = mainAnalysisParams.clusterRad;
peakSize = mainAnalysisParams.peakSize;
trackMaxDisp = mainAnalysisParams.trackMaxDisp;
minTrackLength = mainAnalysisParams.minTrackLength;
peakThresh = mainAnalysisParams.peakThresh;

%% Static Analysis Parameters

% Smoothing Parameters
smoothOneSidedNumSig = 3;
smoothPadSize = ceil(smoothSig.*smoothOneSidedNumSig);
smoothMeanFac = 1;
smoothSigFac = 10;

% Difference Image Parameters
numFrames = 3;

% Optical Flow Calculation
relThresh = 0;

% Optical Flow Enhancement Parameters
enhSig = [2, 2, .5];
enhNumSig = 3;
enhBgSubSig = [8, 8, 2];

%% Import Images
if exist([exportFolder, 'OriginalImage.mat'], 'file')
    fprintf('- Original Image Located\n');
else
    fprintf('- Importing Original Image\n');
    ImportImage(importFolder, exportFolder, fileName);
end

%% Smooth Original Images
if exist([exportFolder, 'SmoothedImages.mat'], 'file')
    fprintf('- Smoothed Image Located\n');
else
    % Load Dependencies
    fprintf('- Loading Original Image for Smoothing\n');
    load([exportFolder, 'OriginalImage.mat'], 'OriginalImage');
    origImage = OriginalImage.Image(:, :, :, OriginalImage.ActinChannel);
    % Perform Smoothing
    fprintf('  Creating Smoothed Image\n');
    SmoothImages(exportFolder, smoothSig, origImage);
end

%% Calculate Optical Flow
if exist([exportFolder, 'OpticalFlow.mat'], 'file')
    fprintf('- Optical Flow Images Located\n');
else
    % Load Dependencies
    fprintf('- Loading Image for Optical Flow Calculations\n');
    load([exportFolder, 'OriginalImage.mat'], 'OriginalImage');
    origImage = squeeze(OriginalImage.Image(:, :, :, OriginalImage.ActinChannel));
    % Calculate Optical Flow
    fprintf('  Calculating Optical Flow\n');
    CalculateOpticalFlow(exportFolder, wSig, origImage);
end

%% Calculate Difference Image
if exist([exportFolder, 'DifferenceImage.mat'], 'file')
    fprintf('- Difference Image Located\n');
else
    % Load dependencies
    if ~exist('origImage', 'var')
        fprintf('- Loading Original Image for Difference Image Calculation\n');
        load([exportFolder, 'OriginalImage.mat'], 'OriginalImage');
        origImage = squeeze(OriginalImage.Image(:, :, :, OriginalImage.ActinChannel));
    end
    if ~exist('smoothImage', 'var')
        fprintf('  Loading Smoothed Image for Difference Image Calculation\n');
        load([exportFolder, 'SmoothedImages.mat'], 'smoothImage');
    end   
    % Create Difference Image
    fprintf('  Creating Difference Image\n');
    CalculateDifferenceImage(exportFolder, numFrames, origImage, smoothImage);
end

%% Enhance Optical Flow
% if exist([exportFolder, 'EnhancedImage.mat'], 'file')
%     fprintf('- Enhanced Optical Flow Image Located\n'); 
% else
%     % Load Dependencies
%     fprintf('- Loading Images for Optical Flow Image Enhancement\n');
%     fprintf('  Loading Original Image for Difference Image Calculation\n');
%     if ~exist('origImage', 'var')
%         load([exportFolder, 'OriginalImage.mat'], 'OriginalImage');
%         origImage = squeeze(OriginalImage.Image(:, :, :, OriginalImage.ActinChannel));
%     end
%     fprintf('  Loading Difference Image for Optical Flow Image Enhancement\n');
%     if ~exist('smoothDiffImage', 'var')
%         load([exportFolder, 'DifferenceImage.mat'], 'smoothDiffImage');
%     end
%     fprintf('  Loading Optical Flow Images for Optical Flow Image Enhancement\n');
%     if ~exist('relMat', 'var')
%         load([exportFolder, 'OpticalFlow.mat'], 'relMat');
%     end
%     % Enhance Optical Flow Images
%     fprintf('  Enhancing Images\n');
%     EnhanceOpticalFlow(exportFolder, floor(minR):ceil(maxR), relMat, origImage, smoothDiffImage);
% end

%% Track Flow Clusters
if exist([exportFolder, 'FlowClusterTracks.mat'], 'file')
    fprintf('- Flow Cluster Tracks Located\n');
else
    if ~exist('smoothDiffImage', 'var')
        fprintf('- Loading Difference Image for Flow Cluster Tracking\n');
        load([exportFolder, 'DifferenceImage.mat'], 'smoothDiffImage');
        str = ' ';
    else
        str = '-';
    end   
    if ~exist('vxMat', 'var')
        fprintf([str, ' Loading Optical Flow Images for Flow Cluster Tracking\n']);
        load([exportFolder, 'OpticalFlow.mat'], 'vxMat', 'vyMat', 'relMat');
        str = ' ';
    else
        str = '-';
    end   
%     fprintf([str, ' Loading Enhanced Optical Flow Images for Flow Cluster Tracking\n']);
%     load([exportFolder, 'EnhancedImage.mat'], 'enhMatPos', 'enhMatNeg');
    fprintf('  Tracking Flow Clusters\n');
    clusterTrackParams.clusterRad = clusterRad;
    clusterTrackParams.peakThresh = peakThresh;
    clusterTrackParams.peakSize = peakSize;
    clusterTrackParams.trackMaxDisp = trackMaxDisp;
    TrackFlowClusters(exportFolder, clusterTrackParams, smoothDiffImage, relMat, relMat, vxMat, vyMat);
end