function TrackFlowClusters(exportFolder, clusterTrackParams, smoothDiffImage, relMat, ~, vxMat, vyMat)
%% Create folder
trackFolder = [exportFolder, 'TrackFigure', filesep];
if ~exist(trackFolder, 'dir')
    mkdir(trackFolder);
end

%% Import params
clusterRad = clusterTrackParams.clusterRad;
peakThresh = clusterTrackParams.peakThresh;
peakSize = clusterTrackParams.peakSize;
trackMaxDisp = clusterTrackParams.trackMaxDisp;

%% Create cluster image
% Set up flow images
% mag = sqrt(vxMat.^2 + vyMat.^2); 
% vxMat(mag(:) > 0) = vxMat(mag(:) > 0)./mag(mag(:) > 0); 
% vyMat(mag(:) > 0) = vyMat(mag(:) > 0)./mag(mag(:) > 0);

% Calculate flow alignment
clusterFil = fspecial('gaussian', ceil(6*clusterRad + 1), clusterRad);
clusterFil((size(clusterFil, 1) + 1)/2, (size(clusterFil, 2) + 1)/2) = 0; 
clusterFil = clusterFil/sum(clusterFil(:));
filFlow = (vxMat.*imfilter(vxMat, clusterFil) + vyMat.*imfilter(vyMat, clusterFil)).^2;

% Calculate cluster image
sz3 = size(smoothDiffImage, 3);
% clusterImPos = enhMatPos.*filFlow(:, :, 1:sz3).*double(smoothDiffImage > 0);
% clusterImNeg = enhMatNeg.*filFlow(:, :, 1:sz3).*double(smoothDiffImage < 0);
relThresh = 10*median(relMat(:));
clusterImPos = filFlow(:, :, 1:sz3).*double(smoothDiffImage(:, :, 1:sz3) > 0 & relMat(:, :, 1:sz3) > relThresh);
clusterImNeg = filFlow(:, :, 1:sz3).*double(smoothDiffImage(:, :, 1:sz3) < 0 & relMat(:, :, 1:sz3) > relThresh);

%% Find peaks in cluster image
xytPos = [];
xytNeg = [];
for i = 1:size(clusterImPos, 3)
    pksPos = pkfnd(clusterImPos(:, :, i), peakThresh, peakSize);
    pks2Pos = cntrd(clusterImPos(:, :, i), pksPos, peakSize);
    pksNeg = pkfnd(clusterImNeg(:, :, i), peakThresh, peakSize);
    pks2Neg = cntrd(clusterImNeg(:, :, i), pksNeg, peakSize);
    if isempty(pks2Pos)
        pks2Pos = [];
    else
        pks2Pos = pks2Pos(:, [1, 2]);
    end
    if isempty(pks2Neg)
        pks2Neg = [];
    else
        pks2Neg = pks2Neg(:, [1, 2]);
    end
    xytPos = [xytPos; [pks2Pos, zeros(size(pks2Pos, 1), 1) + i]]; %#ok<AGROW>
    xytNeg = [xytNeg; [pks2Neg, zeros(size(pks2Neg, 1), 1) + i]]; %#ok<AGROW>
end

%% Track peaks
if size(xytPos, 1) >= 2
    tracksPos = track(xytPos, trackMaxDisp);
else
    tracksPos = zeros(0, 4);
end
if size(xytNeg, 1) >= 2
    tracksNeg = track(xytNeg, trackMaxDisp);
else
    tracksNeg = zeros(0, 4);
end

%% Save results
save([exportFolder, 'FlowClusterTracks.mat'], 'xytPos', 'xytNeg', 'tracksPos', 'tracksNeg', 'clusterImPos', 'clusterImNeg', 'peakThresh', 'clusterTrackParams');
end

