clear all;
close all
clc;

%% Date (format: YYYY MM DD)
date = '2020 1 8';

%% Data used
datatype = 2;
if datatype == 1
    dataName = 'HL60';
    HL60Data;
elseif datatype == 2
    dataName = 'M1';
    M1Data;
end

%% Batch procedures

% Run analysis code
runCode = 0;
if runCode == 1
    run(1) = 1; % MainAnalysisScript
    run(2) = 1; % FlowFigureData
    run(3) = 0; % FlowFigureImages
    run(4) = 1; % FlowDistributionData
    run(5) = 1; % FlowClusterTracksData
    run(6) = 1; % FlowClusterTracksMovies
end

% Accumulate and plot velocity data
accumVels = 0;
plotVels = 0; % <-- needs accumVels = 1

% Accumulate and plot cell flow angle data
accumFlowAngs = 0;
plotFlowAngs_distributions = 0; % <-- needs accumFlowAngs = 1
plotFlowAngs_distr_with_lines = 0; % <-- ne eds accumFlowAngs = 1
fitCellFlowAngDistributions = 0 ;

% Accumulate and plot track angle data
accumTrackAngs = 1;
plotTrackAngs_distributions = 1; % <-- needs accumTrackAngs = 1
plotTrackAngs_spiderPlots = 0; % <-- needs accumTrackAngs = 1

% Accumulate and plot angle data
angRange = '360'; % <-- either '90' or '360'
angStepSize = 15;

% Accumulate and plot MFPT data
epsListxinMicrons = 0:0.1:10;
accumMFPTxData = 0;
plotMFPTxData = 0; % <-- needs accumMFPTxData = 1

%% Accumulate and save data
for fileNum = 1:length(fileNameList)
    %% File parameters
    fileName = fileNameList{fileNum};
    thetaInDegrees = -fileAngleList(fileNum);
    thetaInRadians = thetaInDegrees*pi/180;
    dataGroup = dataGroupList(fileNum);
    dataGroupName = dataGroupNameList{dataGroup};
    
    %% Declare Folders
    if datatype == 1
        % HL60 Data
        % Define import folder
        importFolder = 'D:\Google Drive\Optical Flow Analysis of Actin Waves\Data from Ava\';
        % Define export folder
        exportFolder = ['D:\Google Drive\Optical Flow Analysis of Actin Waves\Output\HL60 6\', fileName(1:(end-4)), '\'];
    elseif datatype == 2
        % M1 Data
        % Define import folder
        importFolder = 'D:\Google Drive\Optical Flow Analysis of Actin Waves\Phillip\';
        % Define export folder
        exportFolder = ['D:\Google Drive\Optical Flow Analysis of Actin Waves\Output\M1 5\', fileName(1:(end-4)), '\'];
    end
    
    %% Run Code
    if runCode == 1
        ControlScriptBatch(run, M1_spatial_multiplier, M1_time_multiplier, M1_peakThresh_multiplier, timeBtwFrames, fileName, importFolder, exportFolder, pxPerMicron, timeUnit, thetaInDegrees, dataGroup, dataGroupName);
    end
    
    %% Accumulate velocity data
    if accumVels == 1
        % Load data if available
        fileName1 = [date, ' - ', dataName, ' - AccumulatedVelocityData.mat'];
        if exist(fileName1, 'file')
            saveFile1 = 0;
        else
            % Save the file after compiling
            saveFile1 = 1;
            % Load file
            load([exportFolder, 'TrackFigure', filesep, 'FlowClusterTracksData.mat'], 'PosTrackVels', 'numCells');
            % Accumulate Whole Movie Velocity Data
            if fileNum == 1
                % Initialize variables
                allInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                allAvgInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                longInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                longAvgInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
            end
            % Velocities from all tracks
            currData1 = PosTrackVels.allSmooth.Velocities;
            currData2 = PosTrackVels.allSmooth.AvgInstVelocity;
            allInstVelData{dataGroup, 2} = [allInstVelData{dataGroup, 2}; cat(1, currData1{:})];
            allAvgInstVelData{dataGroup, 2} = [allAvgInstVelData{dataGroup, 2}; currData2];
            % Velocities from long tracks
            currData1 = PosTrackVels.longSmooth.Velocities;
            currData2 = PosTrackVels.longSmooth.AvgInstVelocity;
            longInstVelData{dataGroup, 2} = [longInstVelData{dataGroup, 2}; cat(1, currData1{:})];
            longAvgInstVelData{dataGroup, 2} = [longAvgInstVelData{dataGroup, 2}; currData2];
            % Accumulate cell-by-cell data
            for cellNum = 1:numCells
                % Load data
                load([exportFolder, 'TrackFigure', filesep, 'FlowClusterTracksData_Cell', num2str(cellNum), 'of', num2str(numCells),'.mat'], 'PosTrackVels');
                % Initialize variables
                if (fileNum == 1) && (cellNum == 1)
                    cellInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellAvgInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellLongInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellLongAvgInstVelData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                end
                % All tracks
                currData1 = PosTrackVels.allSmooth.Velocities;
                currData2 = PosTrackVels.allSmooth.AvgInstVelocity;
                cellInstVelData{dataGroup, 2} = [cellInstVelData{dataGroup, 2}; {cat(1, currData1{:})}];
                cellAvgInstVelData{dataGroup, 2} = [cellAvgInstVelData{dataGroup, 2}; {currData2}];
                % Long tracks
                currData1 = PosTrackVels.longSmooth.Velocities;
                currData2 = PosTrackVels.longSmooth.AvgInstVelocity;
                cellLongInstVelData{dataGroup, 2} = [cellLongInstVelData{dataGroup, 2}; {cat(1, currData1{:})}];
                cellLongAvgInstVelData{dataGroup, 2} = [cellLongAvgInstVelData{dataGroup, 2}; {currData2}];
            end
        end
    else
        saveFile1 = 0;
    end
    
    %% Accumulate Flow Angle data
    if accumFlowAngs == 1
        %Load data if available
        fileName2 = [date, ' - ', dataName,' - AccumulatedFlowAngleData.mat'];
        if exist(fileName2, 'file')
            saveFile2 = 0;
        else
            % Save the file after compiling
            saveFile2 = 1;
            % Load file
            load([exportFolder, 'FlowFigure', filesep, 'FlowDistributionData.mat'], 'FlowDistributionData', 'numCells');
            % Initialize variables
            if fileNum == 1
                movieFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                moviePosFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                movieNegFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
            end
            % Accumulate whole movie data
            movieFlowAngList{dataGroup, 2} = [movieFlowAngList{dataGroup, 2}; FlowDistributionData.FullAngList];
            moviePosFlowAngList{dataGroup, 2} = [moviePosFlowAngList{dataGroup, 2}; FlowDistributionData.FullAngList(FlowDistributionData.DifferenceImageFactor == 1)];
            movieNegFlowAngList{dataGroup, 2} = [movieNegFlowAngList{dataGroup, 2}; FlowDistributionData.FullAngList(FlowDistributionData.DifferenceImageFactor == -1)];
            % Accumulate cell-by-cell data
            for cellNum = 1:numCells  
                % Load file
                load([exportFolder, 'FlowFigure', filesep, 'FlowDistributionData_Cell', num2str(cellNum), 'of', num2str(numCells), '.mat'], 'FlowDistributionData', 'NegClusterFlowDistributionData', 'PosClusterFlowDistributionData');
                % Initialize variables
                if (fileNum == 1) && (cellNum == 1)
                    cellFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellPosFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellNegFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    clusterFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    clusterPosFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    clusterNegFlowAngList = [dataGroupNameList, cell(max(dataGroupList), 1)];
                end
                % Accumulate data
                cellFlowAngList{dataGroup, 2} = [cellFlowAngList{dataGroup, 2}; {FlowDistributionData.FullAngList}];
                cellPosFlowAngList{dataGroup, 2} = [cellPosFlowAngList{dataGroup, 2}; {FlowDistributionData.FullAngList(FlowDistributionData.DifferenceImageFactor == 1)}];
                cellNegFlowAngList{dataGroup, 2} = [cellNegFlowAngList{dataGroup, 2}; {FlowDistributionData.FullAngList(FlowDistributionData.DifferenceImageFactor == -1)}];
                clusterFlowAngList{dataGroup, 2} = [clusterFlowAngList{dataGroup, 2}; {PosClusterFlowDistributionData.FullAngList}];
                clusterPosFlowAngList{dataGroup, 2} = [clusterPosFlowAngList{dataGroup, 2}; {PosClusterFlowDistributionData.FullAngList}];
                clusterNegFlowAngList{dataGroup, 2} = [clusterNegFlowAngList{dataGroup, 2}; {NegClusterFlowDistributionData.FullAngList}];
            end
        end
    else
        saveFile2 = 0;
    end
    
    %% Accumulate Track Angle data
    if accumTrackAngs == 1
        %Load data if available
        fileName3 = [date, ' - ', dataName,' - AccumulatedTrackAngleData.mat'];
        if exist(fileName3, 'file')
            saveFile3 = 0;
        else
            % Save data after
            saveFile3 = 1;
            % Load file
            load([exportFolder, 'TrackFigure', filesep, 'FlowClusterTracksData.mat'], 'PosTrackAngs', 'numCells');
            % Accumulate Whole Movie Track Angle Data
            if fileNum == 1
                % Initialize variables
                allInstAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                allAvgAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                longInstAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                longAvgAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
            end
            % Angles from all tracks
            currData1 = PosTrackAngs.allSmooth.Angles;
            currData2 = PosTrackAngs.allSmooth.AvgAngle;
            allInstAngData{dataGroup, 2} = [allInstAngData{dataGroup, 2}; cat(1, currData1{:})];
            allAvgAngData{dataGroup, 2} = [allAvgAngData{dataGroup, 2}; currData2];
            % Angles from long tracks
            currData1 = PosTrackAngs.longSmooth.Angles;
            currData2 = PosTrackAngs.longSmooth.AvgAngle;
            longInstAngData{dataGroup, 2} = [longInstAngData{dataGroup, 2}; cat(1, currData1{:})];
            longAvgAngData{dataGroup, 2} = [longAvgAngData{dataGroup, 2}; currData2(currData2 ~= 0)];
            % Accumulate cell-by-cell data
            for cellNum = 1:numCells
                % Load data
                load([exportFolder, 'TrackFigure', filesep, 'FlowClusterTracksData_Cell', num2str(cellNum), 'of', num2str(numCells),'.mat'], 'PosTrackAngs');
                % Initialize variables
                if (fileNum == 1) && (cellNum == 1)
                    cellInstAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellAvgAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellLongInstAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                    cellLongAvgAngData = [dataGroupNameList, cell(max(dataGroupList), 1)];
                end
                % All tracks
                currData1 = PosTrackAngs.allSmooth.Angles;
                currData2 = PosTrackAngs.allSmooth.AvgAngle;
                cellInstAngData{dataGroup, 2} = [cellInstAngData{dataGroup, 2}; {cat(1, currData1{:})}];
                cellAvgAngData{dataGroup, 2} = [cellAvgAngData{dataGroup, 2}; {currData2(currData2 ~= 0)}];
                % Long tracks
                currData1 = PosTrackAngs.longSmooth.Angles;
                currData2 = PosTrackAngs.longSmooth.AvgAngle;
                cellLongInstAngData{dataGroup, 2} = [cellLongInstAngData{dataGroup, 2}; {cat(1, currData1{:})}];
                cellLongAvgAngData{dataGroup, 2} = [cellLongAvgAngData{dataGroup, 2}; {currData2(currData2 ~= 0)}];
            end
            
        end
    else
        saveFile3 = 0;
    end
    
    %%  End of loop
    fprintf(['\nFile number ', num2str(fileNum), ' of ', num2str(length(fileNameList)), ' complete.\n']);
    
end
% Save files
if accumVels == 1 && saveFile1 == 1
    save(fileName1, 'allInstVelData', 'allAvgInstVelData', 'longInstVelData', 'longAvgInstVelData', ...
        'cellInstVelData', 'cellAvgInstVelData', 'cellLongInstVelData', 'cellLongAvgInstVelData');
end
if accumFlowAngs == 1 && saveFile2 == 1
    save(fileName2, 'movieFlowAngList', 'moviePosFlowAngList', 'movieNegFlowAngList', ...
        'cellFlowAngList', 'cellPosFlowAngList', 'cellNegFlowAngList', ...
        'clusterFlowAngList', 'clusterPosFlowAngList', 'clusterNegFlowAngList');
end
if accumTrackAngs == 1 && saveFile3 == 1
    save(fileName3, 'allInstAngData', 'allAvgAngData', 'longInstAngData', 'longAvgAngData', ...
        'cellInstAngData', 'cellAvgAngData', 'cellLongInstAngData', 'cellLongAvgAngData');
end

%% Plot Vels
if plotVels == 1
    
    % Load files
    load(fileName1, 'allInstVelData', 'allAvgInstVelData', 'longInstVelData', 'longAvgInstVelData', ...
        'cellInstVelData', 'cellAvgInstVelData', 'cellLongInstVelData', 'cellLongAvgInstVelData');
    
    % Plot movie data
    if datatype == 1
        xVec = 0:2:25;
        xTick = 0:5:25;
        xTickLabel = {'0', '5', '10', '15', '20', '25'};
        dataGroupData1 = allInstVelData{1, 2};
        dataGroupData2 = allInstVelData{3, 2};
    elseif datatype == 2
        xVec = 0:0.4:6;
        xTick = 0:1:6;
        xTickLabel = {'0', '', '2', '', '4', '', '6'};
        dataGroupData1 = allInstVelData{2, 2};
        dataGroupData2 = allInstVelData{3, 2};
    end
    yVec1 = histcounts(dataGroupData1, xVec);
    yVec2 = histcounts(dataGroupData2, xVec);
    PlotTwoVelocityDistributions(xVec, yVec1, yVec2, [date, ' - ', dataName, ' - AllVelocityDistributions'], xTick, xTickLabel);
    
    if datatype == 1
        dataGroupData1 = longInstVelData{1, 2};
        dataGroupData2 = longInstVelData{3, 2};
    elseif datatype == 2
        dataGroupData1 = longInstVelData{2, 2};
        dataGroupData2 = longInstVelData{3, 2};
    end
    yVec1 = histcounts(dataGroupData1, xVec);
    yVec2 = histcounts(dataGroupData2, xVec);
    PlotTwoVelocityDistributions(xVec, yVec1, yVec2, [date, ' - ', dataName, ' - LongVelocityDistributions'], xTick, xTickLabel);
    
    
    % Plot cell-by-cell data
    if datatype == 1
        dataGroupData1 = cellInstVelData{1, 2};
        dataGroupData2 = cellInstVelData{3, 2};
    elseif datatype == 2
        dataGroupData1 = cellInstVelData{2, 2};
        dataGroupData2 = cellInstVelData{3, 2};
    end
    numCells1 = size(dataGroupData1, 1);
    numCells2 = size(dataGroupData2, 1);
    yVec1 = zeros(numCells1, length(xVec) - 1);
    yVec2 = zeros(numCells2, length(xVec) - 1);
    for i = 1:numCells1
        yVec1(i, :) = histcounts(dataGroupData1{i}, xVec);
    end
    for i = 1:numCells2
        yVec2(i, :) = histcounts(dataGroupData2{i}, xVec);
    end
    yVec1 = sum(yVec1, 1);
    yVec2 = sum(yVec2, 1);
    PlotTwoVelocityDistributions(xVec, yVec1, yVec2, [date, ' - ', dataName, ' - AllCellVelocityDistributions'], xTick, xTickLabel);
    
    if datatype == 1
        dataGroupData1 = cellLongInstVelData{1, 2};
        dataGroupData2 = cellLongInstVelData{3, 2};
    elseif datatype == 2
        dataGroupData1 = cellLongInstVelData{2, 2};
        dataGroupData2 = cellLongInstVelData{3, 2};
    end
    yVec1 = zeros(numCells1, length(xVec) - 1);
    yVec2 = zeros(numCells2, length(xVec) - 1);
    for i = 1:numCells1
        yVec1(i, :) = histcounts(dataGroupData1{i}, xVec);
    end
    for i = 1:numCells2
        yVec2(i, :) = histcounts(dataGroupData2{i}, xVec);
    end
    yVec1 = sum(yVec1, 1);
    yVec2 = sum(yVec2, 1);
    PlotTwoVelocityDistributions(xVec, yVec1, yVec2, [date, ' - ', dataName, ' - LongCellVelocityDistributions'], xTick, xTickLabel);
    
end

%% Plot Flow Angs
if plotFlowAngs_distributions == 1
    
    % Flow distribution plots
    load(fileName2, 'movieFlowAngList');
    if datatype == 1
        dataGroupData1 = movieFlowAngList{1, 2};
        dataGroupData2 = movieFlowAngList{3, 2};
    elseif datatype == 2
        dataGroupData1 = movieFlowAngList{2, 2};
        dataGroupData2 = movieFlowAngList{3, 2};
    end
    if strcmp(angRange, '90') == 1
        xData = 0:angStepSize:90;
        dataGroupData1 = acos(cos(asin(sin(dataGroupData1))));
        dataGroupData2 = acos(cos(asin(sin(dataGroupData2))));
    elseif strcmp(angRange, '360') == 1
        xData = 0:angStepSize:360;
    end
    counts1 = histcounts(mod(dataGroupData1*180/pi + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
    counts2 = histcounts(mod(dataGroupData2*180/pi + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
    PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - FlowAngleDistributions']);
    
    % Positive flow distribution plots
    load(fileName2, 'moviePosFlowAngList');
    if datatype == 1
        dataGroupData1 = moviePosFlowAngList{1, 2};
        dataGroupData2 = moviePosFlowAngList{3, 2};
    elseif datatype == 2
        dataGroupData1 = moviePosFlowAngList{2, 2};
        dataGroupData2 = moviePosFlowAngList{3, 2};
    end
    if strcmp(angRange, '90') == 1
        xData = 0:angStepSize:90;
        dataGroupData1 = acos(cos(asin(sin(dataGroupData1))));
        dataGroupData2 = acos(cos(asin(sin(dataGroupData2))));
    elseif strcmp(angRange, '360') == 1
        xData = 0:angStepSize:360;
    end
    counts1 = histcounts(mod(dataGroupData1*180/pi + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
    counts2 = histcounts(mod(dataGroupData2*180/pi + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
    PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - PositiveFlowAngleDistributions']);
    
    % Cell-by-cell distribution plots
    load(fileName2, 'cellFlowAngList');
    if datatype == 1
        dataGroupData1 = cellFlowAngList(1, :);
        dataGroupData2 = cellFlowAngList(3, :);
    elseif datatype == 2
        dataGroupData1 = cellFlowAngList(2, :);
        dataGroupData2 = cellFlowAngList(3, :);
    end
    numCells1 = length(dataGroupData1{2});
    numCells2 = length(dataGroupData2{2});
    counts1Sum = [];
    counts2Sum = [];
    for i = 1:numCells1
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acos(cos(asin(sin(dataGroupData1{2}{i}))))*180/pi + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData1{2}{i}*180/pi + angStepSize/2, 360) - angStepSize/2;
        end
        counts1 = histcounts(yData, xData - angStepSize/2);
        counts1Sum = [counts1Sum; counts1];
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData1{1}, ' - Cell', num2str(i), 'of', num2str(numCells1), ' - FlowAngleDistributions']);
    end
    for i = 1:numCells2
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acos(cos(asin(sin(dataGroupData2{2}{i}))))*180/pi + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData2{2}{i}*180/pi + angStepSize/2, 360) - angStepSize/2;
        end
        counts2 = histcounts(yData, xData - angStepSize/2);
        counts2Sum = [counts2Sum; counts2];
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts2, counts2(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData2{1}, ' - Cell', num2str(i), 'of', num2str(numCells2), ' - FlowAngleDistributions']);
    end
    counts1 = sum(counts1Sum, 1);
    counts2 = sum(counts2Sum, 1);
    PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - CellFlowAngleDistributions']);
    
    % Positive cell-by-cell distribution plots
    load(fileName2, 'cellPosFlowAngList');
    if datatype == 1
        dataGroupData1 = cellPosFlowAngList(1, :);
        dataGroupData2 = cellPosFlowAngList(3, :);
    elseif datatype == 2
        dataGroupData1 = cellPosFlowAngList(2, :);
        dataGroupData2 = cellPosFlowAngList(3, :);
    end
    numCells1 = length(dataGroupData1{2});
    numCells2 = length(dataGroupData2{2});
    counts1Sum = [];
    counts2Sum = [];
    for i = 1:numCells1
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acos(cos(asin(sin(dataGroupData1{2}{i}))))*180/pi + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData1{2}{i}*180/pi + angStepSize/2, 360) - angStepSize/2;
        end
        counts1 = histcounts(yData, xData - angStepSize/2);
        counts1Sum = [counts1Sum; counts1];
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData1{1}, ' - Cell', num2str(i), 'of', num2str(numCells1), ' - PositiveClusterFlowAngleDistributions']);
    end
    for i = 1:numCells2
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acos(cos(asin(sin(dataGroupData2{2}{i}))))*180/pi + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData2{2}{i}*180/pi + angStepSize/2, 360) - angStepSize/2;
        end
        counts2 = histcounts(yData, xData - angStepSize/2);
        counts2Sum = [counts2Sum; counts2];
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts2, counts2(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData2{1}, ' - Cell', num2str(i), 'of', num2str(numCells2), ' - PositiveClusterFlowAngleDistributions']);
    end
    counts1 = sum(counts1Sum, 1);
    counts2 = sum(counts2Sum, 1);
    PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - CellPositiveClusterFlowAngleDistributions']);
    
end

%% Plot Track Angs
if plotTrackAngs_distributions == 1
      
%     % Flow distribution plots
%     load(fileName3, 'allInstAngData');
%     if datatype == 1
%         dataGroupData1 = allInstAngData{1, 2};
%         dataGroupData2 = allInstAngData{3, 2};
%     elseif datatype == 2
%         dataGroupData1 = allInstAngData{2, 2};
%         dataGroupData2 = allInstAngData{3, 2};
%     end
%     if strcmp(angRange, '90') == 1
%         xData = 0:angStepSize:90;
%         dataGroupData1 = acos(cos(asin(sin(dataGroupData1))));
%         dataGroupData2 = acos(cos(asin(sin(dataGroupData2))));
%     elseif strcmp(angRange, '360') == 1
%         xData = 0:angStepSize:360;
%     end
%     counts1 = histcounts(mod(dataGroupData1 + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%     counts2 = histcounts(mod(dataGroupData2 + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%     PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - TrackAngleDistributions']);
%     
%     load(fileName3, 'allAvgAngData');
%     if datatype == 1
%         dataGroupData1 = allAvgAngData{1, 2}; dataGroupData1(dataGroupData1(:) == 0) = [];
%         dataGroupData2 = allAvgAngData{3, 2}; dataGroupData2(dataGroupData2(:) == 0) = [];
%     elseif datatype == 2
%         dataGroupData1 = allAvgAngData{2, 2}; dataGroupData1(dataGroupData1(:) == 0) = [];
%         dataGroupData2 = allAvgAngData{3, 2}; dataGroupData2(dataGroupData2(:) == 0) = [];
%     end
%     if strcmp(angRange, '90') == 1
%         xData = 0:angStepSize:90;
%         dataGroupData1 = acos(cos(asin(sin(dataGroupData1))));
%         dataGroupData2 = acos(cos(asin(sin(dataGroupData2))));
%     elseif strcmp(angRange, '360') == 1
%         xData = 0:angStepSize:360;
%     end
%     counts1 = histcounts(mod(dataGroupData1 + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%     counts2 = histcounts(mod(dataGroupData2 + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%     PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - AverageTrackAngleDistributions']);
%     
%     
%     % Positive flow distribution plots
%     load(fileName3, 'longAvgAngData', 'allAvgAngData');
%     if datatype == 1
%         dataGroupData1 = allAvgAngData{1, 2};
%         dataGroupData2 = allAvgAngData{3, 2};
%     elseif datatype == 2
%         dataGroupData1 = allAvgAngData{2, 2};
%         dataGroupData2 = allAvgAngData{3, 2};
%     end
%     if strcmp(angRange, '90') == 1
%         xData = 0:angStepSize:90;
%         dataGroupData1 = acos(cos(asin(sin(dataGroupData1))));
%         dataGroupData2 = acos(cos(asin(sin(dataGroupData2))));
%     elseif strcmp(angRange, '360') == 1
%         xData = 0:angStepSize:360;
%     end
%     counts1 = histcounts(mod(dataGroupData1 + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%     counts2 = histcounts(mod(dataGroupData2 + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%     PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [counts2, counts2(1)], angRange, [date, ' - ', dataName, ' - AverageTrackAngleDistributions']);
%     
    % Cell-by-cell distribution plots
    load(fileName3, 'cellInstAngData');
    if datatype == 1
        dataGroupData1 = cellInstAngData(1, :);
        dataGroupData2 = cellInstAngData(3, :);
    elseif datatype == 2
        dataGroupData1 = cellInstAngData(2, :);
        dataGroupData2 = cellInstAngData(3, :);
    end
    numCells1 = length(dataGroupData1{2});
    numCells2 = length(dataGroupData2{2});
    totalCounts1 = [];
    totalCounts2 = [];
    for i = 1:numCells1
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acosd(cosd(asind(sind(dataGroupData1{2}{i})))) + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData1{2}{i} + angStepSize/2, 360) - angStepSize/2;
        end
        counts1 = histcounts(yData, xData - angStepSize/2);
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData1{1}, ' - Cell', num2str(i), 'of', num2str(numCells1), ' - TrackAngleDistributions']);
        totalCounts1 = [totalCounts1; counts1]; 
    end
    for i = 1:numCells2
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acosd(cosd(asind(sind(dataGroupData2{2}{i})))) + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData2{2}{i} + angStepSize/2, 360) - angStepSize/2;
        end
        counts2 = histcounts(mod(dataGroupData2{2}{i} + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts2, counts2(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData2{1}, ' - Cell', num2str(i), 'of', num2str(numCells2), ' - TrackAngleDistributions']);
        totalCounts2 = [totalCounts2; counts2]; 
    end
    totalCounts1 = sum(totalCounts1./(sum(totalCounts1, 2) + eps), 1);
    totalCounts2 = sum(totalCounts2./(sum(totalCounts2, 2) + eps), 1);
    PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [totalCounts1, totalCounts1(1)], [totalCounts2, totalCounts2(1)], angRange, [date, ' - ', dataName, ' - TrackAngleDistributions_EqualCellWeighted']);

    % Cell-by-cell distribution plots
    load(fileName3, 'cellAvgAngData');
    if datatype == 1
        dataGroupData1 = cellAvgAngData(1, :);
        dataGroupData2 = cellAvgAngData(3, :);
    elseif datatype == 2
        dataGroupData1 = cellAvgAngData(2, :);
        dataGroupData2 = cellAvgAngData(3, :);
    end
    numCells1 = length(dataGroupData1{2});
    numCells2 = length(dataGroupData2{2});
    totalCounts1 = [];
    totalCounts2 = [];
    for i = 1:numCells1
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acosd(cosd(asind(sind(dataGroupData1{2}{i})))) + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData1{2}{i} + angStepSize/2, 360) - angStepSize/2;
        end
        counts1 = histcounts(yData, xData - angStepSize/2);
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData1{1}, ' - Cell', num2str(i), 'of', num2str(numCells1), ' - AverageTrackAngleDistributions']);
        totalCounts1 = [totalCounts1; counts1]; 
    end
    for i = 1:numCells2
        if strcmp(angRange, '90') == 1
            xData = 0:angStepSize:90;
            yData = mod(acosd(cosd(asind(sind(dataGroupData2{2}{i})))) + angStepSize/2, 360) - angStepSize/2;
        elseif strcmp(angRange, '360') == 1
            xData = 0:angStepSize:360;
            yData = mod(dataGroupData2{2}{i} + angStepSize/2, 360) - angStepSize/2;
        end
        counts2 = histcounts(mod(dataGroupData2{2}{i} + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
        PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts2, counts2(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData2{1}, ' - Cell', num2str(i), 'of', num2str(numCells2), ' - AverageTrackAngleDistributions']);
        totalCounts2 = [totalCounts2; counts2]; 
    end
    totalCounts1 = sum(totalCounts1./(sum(totalCounts1, 2) + eps), 1);
    totalCounts2 = sum(totalCounts2./(sum(totalCounts2, 2) + eps), 1);
    PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [totalCounts1, totalCounts1(1)], [totalCounts2, totalCounts2(1)], angRange, [date, ' - ', dataName, ' - AverageTrackAngleDistributions_EqualCellWeighted']);
    
%     % Positive cell-by-cell distribution plots
%     load(fileName3, 'cellAvgAngData');
%     if datatype == 1
%         dataGroupData1 = cellAvgAngData(1, :);
%         dataGroupData2 = cellAvgAngData(3, :);
%     elseif datatype == 2
%         dataGroupData1 = cellAvgAngData(2, :);
%         dataGroupData2 = cellAvgAngData(3, :);
%     end
%     numCells1 = length(dataGroupData1{2});
%     numCells2 = length(dataGroupData2{2});
%     for i = 1:numCells1
%         if strcmp(angRange, '90') == 1
%             xData = 0:angStepSize:90;
%             yData = mod(acosd(cosd(asind(sind(dataGroupData1{2}{i})))) + angStepSize/2, 360) - angStepSize/2;
%         elseif strcmp(angRange, '360') == 1
%             xData = 0:angStepSize:360;
%             yData = mod(dataGroupData1{2}{i} + angStepSize/2, 360) - angStepSize/2;
%         end
%         counts1 = histcounts(yData, xData - angStepSize/2);
%         PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts1, counts1(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData1{1}, ' - Cell', num2str(i), 'of', num2str(numCells1), ' - PositiveFlowAngleDistributions']);
%     end
%     for i = 1:numCells2
%         if strcmp(angRange, '90') == 1
%             xData = 0:angStepSize:90;
%             yData = mod(acosd(cosd(asind(sind(dataGroupData2{2}{i})))) + angStepSize/2, 360) - angStepSize/2;
%         elseif strcmp(angRange, '360') == 1
%             xData = 0:angStepSize:360;
%             yData = mod(dataGroupData2{2}{i} + angStepSize/2, 360) - angStepSize/2;
%         end
%         counts2 = histcounts(mod(dataGroupData2{2}{i} + angStepSize/2, 360) - angStepSize/2, xData - angStepSize/2);
%         PlotAngleDistribution([xData, xData(1)] - angStepSize/2, [counts2, counts2(1)], [], angRange, [date, ' - ', dataName, ' - ', dataGroupData2{1}, ' - Cell', num2str(i), 'of', num2str(numCells2), ' - PositiveFlowAngleDistributions']);
%     end
    
end


%% Fit data to model
if fitCellFlowAngDistributions == 1
    
    % Cell-by-cell fits
    load(fileName2, 'cellFlowAngList');
    ThreeParamVonMisesFitData = [];
    FourParamVonMisesFitData = [];
    for dataGroup = 1:length(dataGroupNameList)
        dataGroupData = cellFlowAngList{dataGroup, 2};
        numCells = length(dataGroupData);
        for cellNum = 1:numCells
            angList = dataGroupData{cellNum};
            if ~isempty(angList)
                if strcmp(angRange, '90')
                    angList = [angList; pi - angList; pi + angList; 2*pi - angList];
                end
                [mu, k, p] = MixedVonMisesFit(angList);
                ThreeParamVonMisesFitData = [ThreeParamVonMisesFitData; [dataGroup, mu, k, p]];
                b = [mu; k; p; 1 - p; 0];
                options = optimoptions('fminunc','algorithm', 'quasi-newton', 'SpecifyObjectiveGradient', true);
                [b, o1, o2, o3, o4, o5] = fminunc(@(b) VMMix_logF(angList, b), b, options);
                FourParamVonMisesFitData = [FourParamVonMisesFitData; [dataGroup, (b(:))']];
            else
                ThreeParamVonMisesFitData = [ThreeParamVonMisesFitData; [dataGroup, nan(1, 3)]];
                FourParamVonMisesFitData = [FourParamVonMisesFitData; [dataGroup, nan(1, 5)]];
            end
        end
        cellFlowAngList{dataGroup, 3} = ThreeParamVonMisesFitData(ThreeParamVonMisesFitData(:, 1) == dataGroup, :);
        cellFlowAngList{dataGroup, 4} = FourParamVonMisesFitData(FourParamVonMisesFitData(:, 1) == dataGroup, :);
    end
    FourParamVonMisesFitData(FourParamVonMisesFitData(:, 4) < FourParamVonMisesFitData(:, 5), 2) = mod(FourParamVonMisesFitData(FourParamVonMisesFitData(:, 4) < FourParamVonMisesFitData(:, 5), 2) + 2*pi, 2*pi) - pi;
    FourParamVonMisesFitData(FourParamVonMisesFitData(:, 4) < FourParamVonMisesFitData(:, 5), [4, 5]) = FourParamVonMisesFitData(FourParamVonMisesFitData(:, 4) < FourParamVonMisesFitData(:, 5), [5, 4]);
    save([date, ' - VonMisesFitData - CellByCell - ', dataName, '.mat'], 'ThreeParamVonMisesFitData', 'FourParamVonMisesFitData');
    
    %     % Cell-by-cell cluster fits
    %     ThreeParamVonMisesFitData = [];
    %     FourParamVonMisesFitData = [];
    %     for dataGroup = 1:length(dataGroupNameList)
    %         dataGroupData = clusterFlowAngList{dataGroup, 2};
    %         numCells = length(dataGroupData);
    %         for cellNum = 1:numCells
    %             angList = dataGroupData{cellNum};
    %             if ~isempty(angList)
    %                 if strcmp(angRange, '90')
    %                     angList = [angList; pi - angList; pi + angList; 2*pi - angList];
    %                 end
    %                 [mu, k, p] = MixedVonMisesFit(angList);
    %                 ThreeParamVonMisesFitData = [ThreeParamVonMisesFitData; [dataGroup, mu, k, p]];
    %                 b = [mu; k; p; 1 - p; 0];
    %                 options = optimoptions('fminunc','algorithm', 'quasi-newton', 'SpecifyObjectiveGradient',true);
    %                 [b, o1, o2, o3, o4, o5] = fminunc(@(b) VMMix_logF(angList, b), b, options);
    %                 FourParamVonMisesFitData = [FourParamVonMisesFitData; [dataGroup, (b(:))']];
    %             else
    %                 ThreeParamVonMisesFitData = [ThreeParamVonMisesFitData; [dataGroup, nan(1, 3)]];
    %                 FourParamVonMisesFitData = [FourParamVonMisesFitData; [dataGroup, nan(1, 5)]];
    %             end
    %         end
    %         clusterFlowAngList{dataGroup, 3} = ThreeParamVonMisesFitData(ThreeParamVonMisesFitData(:, 1) == dataGroup, :);
    %         clusterFlowAngList{dataGroup, 4} = FourParamVonMisesFitData(FourParamVonMisesFitData(:, 1) == dataGroup, :);
    %     end
    %     save([date, ' - VonMisesFitData - Cluster - ', dataName, '.mat'], 'ThreeParamVonMisesFitData', 'FourParamVonMisesFitData');
    
end

%%
if 0
    %% Plot data and fits
    close all;
    tempAngStepSize = angStepSize/2;
    load([date, ' - VonMisesFitData - CellByCell - ', dataName, '.mat'], 'ThreeParamVonMisesFitData', 'FourParamVonMisesFitData');
    for dataGroup = 1:length(dataGroupNameList)
        dataGroupData = cellFlowAngList{dataGroup, 2};
        numCells = length(dataGroupData);
        currThreeParamFit = ThreeParamVonMisesFitData(ThreeParamVonMisesFitData(:, 1) == dataGroup, :);
        currFourParamFit = FourParamVonMisesFitData(ThreeParamVonMisesFitData(:, 1) == dataGroup, :);
        for cellNum = 1:numCells
            angList = dataGroupData{cellNum};
            b = currThreeParamFit(cellNum, :);
            b2 = currFourParamFit(cellNum, :);
            
            figure;
            
            subplot(1, 2, 1);
            polarhistogram(angList, linspace(-pi, pi, (360/2/tempAngStepSize)), 'normalization', 'probability');
            hold on;
            x = linspace(-pi, pi, 10*360/tempAngStepSize);
            y = VMMix_f(x, [b(2:4), 1 - b(4), 0]);
            polarplot(x, y/sum(y)*20, 'linewidth', 2);
            hold off;
            title('Bimodal Von Mises');
            
            subplot(1, 2, 2);
            polarhistogram(angList, linspace(-pi, pi, (360/2/tempAngStepSize)), 'normalization', 'probability');
            hold on;
            x = linspace(-pi, pi, 10*360/tempAngStepSize);
            y = VMMix_f(x, b2(2:6));
            polarplot(x, y/sum(y)*20, 'linewidth', 2);
            hold off;
            title('Bimodal Von Mises + Constant');
            
            drawnow;
            saveas(gcf, [date, ' - ', dataName, ' - ', dataGroupNameList{dataGroup}, ' - Cell', num2str(cellNum), '.png']);
            close(gcf);
        end
    end
    
end

%% Plot MFPT
if plotMFPTxData == 1
    figure;
    if datatype == 1
        upperLimx = 10;
        upperLimy = 4;
        d1 = longTrackMFPTxData{1, 2};
        d2 = longTrackMFPTxData{2, 2};
        y1 = nanmean(d1, 1);
        y2 = nanmean(d2, 1);
        s1 = nanstd(d1, 1);
        s2 = nanstd(d2, 1);
        n1 = sum(~isnan(d1), 1);
        n2 = sum(~isnan(d2), 1);
        se1 = s1./sqrt(n1 - 1);
        se2 = s2./sqrt(n2 - 1);
        
        plot(epsListxinMicrons, d1*timeBtwFrames/60, 'color', [0 0.4470 0.7410]);
        xlabel(['Displacement (', char(181), 'm)']);
        ylabel('Mean First Passage Time (min)');
        set(gca, 'FontSize', 16);
        xlim([0, upperLimx]);
        ylim([0, upperLimy]);
        legend('HL60 - Flat');
        saveas(gcf, [date, ' - MFPT - Flat - HL60'], 'png');
        plot(epsListxinMicrons, d2*timeBtwFrames/60, 'color', [0.8500 0.3250 0.0980]);
        xlabel(['Displacement (', char(181), 'm)']);
        ylabel('Mean First Passage Time (min)');
        set(gca, 'FontSize', 16);
        xlim([0, upperLimx]);
        ylim([0, upperLimy]);
        legend('HL60 - Ridges');
        saveas(gcf, [date, ' - MFPT - Ridges - HL60'], 'png');
        plot(epsListxinMicrons, [sum(~isnan(d1), 1); sum(~isnan(d2), 1)]', 'linewidth', 2);
        xlabel(['Displacement (', char(181), 'm)']);
        ylabel('Number of Tracks');
        set(gca, 'FontSize', 16);
        xlim([0, upperLimx]);
        legend('HL60 - Flat', 'HL60 - Ridges');
        saveas(gcf, [date, ' - MFPT Number of Tracks - HL60'], 'png');
        plot(epsListxinMicrons, [sum(~isnan(d1), 1)/sum(sum(~isnan(d1), 1)); sum(~isnan(d2), 1)/sum(sum(~isnan(d2), 1))]', 'linewidth', 2);
        xlabel(['Displacement (', char(181), 'm)']);
        ylabel('Normalized Number of Tracks');
        set(gca, 'FontSize', 16);
        xlim([0, upperLimx]);
        legend('HL60 - Flat', 'HL60 - Ridges');
        saveas(gcf, [date, ' - MFPT Normalized Number of Tracks - HL60'], 'png');
        plot(epsListxinMicrons, [nanmean(d1*timeBtwFrames/60, 1); nanmean(d2*timeBtwFrames/60, 1)]');
        xlabel(['Displacement (', char(181), 'm)']);
        ylabel('Average Mean First Passage Time (min)');
        set(gca, 'FontSize', 16);
        xlim([0, upperLimx]);
        ylim([0, upperLimy]);
    elseif datatype == 2
        
    end
end