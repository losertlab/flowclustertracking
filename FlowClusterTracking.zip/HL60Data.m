%% HL60 Data
M1_spatial_multiplier = 1;
M1_time_multiplier = 1;
M1_peakThresh_multiplier = 1;

% set pxSpacing
pxPerMicron = 4.7619;

% set frameRate
timeUnit = 1;
timeBtwFrames = 2;

% define file names
fileNameList = ...
    {'2017-07-13 HL60_Ridges_ADDfmlp 1.tif', ... % counted as ridges, YESFMLP - only get cells in upper 2/3 of movie
    '2017-07-13 HL60_Ridges_NOfmlp 1.tif', ...
    '2017-07-13 HL60_Ridges_NOfmlp 2.tif', ... % actually is flat - only get cells (1) on right 1/3 of movie
    '2017-07-13 HL60_Ridges_NOfmlp 3.tif', ... % counted as ridges - only get cells in upper 2/3 of movie
    '2017-07-31 HL60_Flat_NOfmlp 1.tif', ...
    '2017-07-31 HL60_Flat_NOfmlp 2.tif', ...
    '2017-07-31 HL60_Flat_YESfmlp 1.tif', ...
    '2017-07-31 HL60_Ridges_NOfmlp 1.tif', ...
    '2017-07-31 HL60_Ridges_NOfmlp 2.tif', ...
    '2017-07-31 HL60_Ridges_YESfmlp 1.tif', ...
    '2017-07-31 HL60_Ridges_YESfmlp 2.tif', ...
    '2017-08-04 HL60_Flat_NOfmlp 1.tif', ...
    '2017-08-04 HL60_Flat_NOfmlp 2.tif', ...
    '2017-08-04 HL60_Flat_YESfmlp 1.tif', ...
    '2017-08-04 HL60_Ridges_NOfmlp 1.tif', ...
    '2017-08-04 HL60_Ridges_NOfmlp 2.tif', ...
    '2017-08-04 HL60_Ridges_YESfmlp 1.tif'};

% define experiment labels
fileExperimentList = ...
    {'1', '1', '1', '1', ...
    '2B', '2A', '2B', '2B', '2A', '2B', '2A', ...
    '3B', '3A', '3B', '3B', '3A', '3B'};

% set file angles
angleList = [ ...
    -172.2, -146.8, -1.7, -82.7, -152.3];
expList = unique(fileExperimentList);
for i = 1:length(expList)
    indeces = strcmp(fileExperimentList, expList{i});
    fileIdxList(indeces) = i;
end
fileAngleList = angleList(fileIdxList);

% define Ridge or Flat
fileRidgeList = zeros(size(fileNameList));
fileRidgeList([1, 2, 4, 8, 9, 10, 11, 15, 16, 17]) = 1;
fileFlatList = 1 - fileRidgeList;

% define FMLP or NoFMLP
fileFMLPxList = zeros(size(fileNameList));
fileNoFMLPxList = zeros(size(fileNameList));
fileFMLPxList([1, 7, 10, 11, 14, 17]) = 1;
fileNoFMLPxList([2, 3, 4, 5, 6, 8, 9, 12, 13, 15, 16]) = 1;

% define data groups
dataGroupList = [fileFlatList'.*fileFMLPxList', fileFlatList'.*fileNoFMLPxList', fileRidgeList'.*fileFMLPxList', fileRidgeList'.*fileNoFMLPxList']*[1;2;3;4];
dataGroupNameList = {'Flat - FMLP', 'Flat - No FMLP', 'Ridges - FMLP', 'Ridges - No FMLP'}';

clear angleList expList fileIdxList i indeces fileRidgeList fileFlatList fileFMLPxList fileNoFMLPxList